#!/bin/sh

echo "Setting up PWManager..."
mkdir $HOME/.pwman -m 700
mkdir $HOME/.pwman/.acc -m 700
echo "Done"
