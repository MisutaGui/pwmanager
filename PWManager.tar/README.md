### PWManager  
  
PWManager is an offline (no cloud storage of data) password manager.  
Its aim is to ease password management by taking care of password  
creation and storage.  
  
### USAGE  
  
Before anything, run `setup.sh` script, otherwise you won't be able  
to use this software.  

### Author  
  
Guillermo MORON USON  
guillermo.moron@laposte.net  
